import pytest
import test_helpers

from django.urls import reverse


pytestmark = [pytest.mark.django_db]


def tests_Menu0_list_view(client):
    instance1 = test_helpers.create_menuapp_Menu0()
    instance2 = test_helpers.create_menuapp_Menu0()
    url = reverse("menuapp_Menu0_list")
    response = client.get(url)
    assert response.status_code == 200
    assert str(instance1) in response.content.decode("utf-8")
    assert str(instance2) in response.content.decode("utf-8")


def tests_Menu0_create_view(client):
    url = reverse("menuapp_Menu0_create")
    data = {
        "mapplication": "text",
        "mstatus": 1,
        "mdescription": "text",
        "mcomment": "text",
        "msort": 1,
        "mlink": "text",
    }
    response = client.post(url, data)
    assert response.status_code == 302


def tests_Menu0_detail_view(client):
    instance = test_helpers.create_menuapp_Menu0()
    url = reverse("menuapp_Menu0_detail", args=[instance.pk, ])
    response = client.get(url)
    assert response.status_code == 200
    assert str(instance) in response.content.decode("utf-8")


def tests_Menu0_update_view(client):
    instance = test_helpers.create_menuapp_Menu0()
    url = reverse("menuapp_Menu0_update", args=[instance.pk, ])
    data = {
        "mapplication": "text",
        "mstatus": 1,
        "mdescription": "text",
        "mcomment": "text",
        "msort": 1,
        "mlink": "text",
    }
    response = client.post(url, data)
    assert response.status_code == 302
