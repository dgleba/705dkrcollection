from django.db import models
from django.urls import reverse


class Menu0(models.Model):

    # Fields
    mapplication = models.CharField(max_length=330)
    mstatus = models.IntegerField(default=1)
    created_at = models.DateTimeField(auto_now_add=True, editable=False)
    mdescription = models.CharField(max_length=330)
    mcomment = models.CharField(max_length=330)
    updated_at = models.DateTimeField(auto_now=True, editable=False)
    msort = models.IntegerField(default=50)
    mlink = models.CharField(max_length=930)

    class Meta:
        pass

    def __str__(self):
        return str(self.pk)

    def get_absolute_url(self):
        return reverse("menuapp_Menu0_detail", args=(self.pk,))

    def get_update_url(self):
        return reverse("menuapp_Menu0_update", args=(self.pk,))

