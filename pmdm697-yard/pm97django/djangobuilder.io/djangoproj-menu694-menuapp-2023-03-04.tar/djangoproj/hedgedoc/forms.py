from django import forms
from . import models


class NotesForm(forms.ModelForm):
    class Meta:
        model = models.Notes
        fields = [
            "shortid",
            "title",
            "permission",
            "content",
            "id",
            "alias",
            "viewcount",
            "authorship",
        ]
