from django.contrib import admin
from django import forms

from . import models


class NotesAdminForm(forms.ModelForm):

    class Meta:
        model = models.Notes
        fields = "__all__"


class NotesAdmin(admin.ModelAdmin):
    form = NotesAdminForm
    list_display = [
        "shortid",
        "title",
        "permission",
        "content",
        "id",
        "alias",
        "viewcount",
        "authorship",
    ]
    readonly_fields = [
        "shortid",
        "title",
        "permission",
        "content",
        "id",
        "alias",
        "viewcount",
        "authorship",
    ]


admin.site.register(models.Notes, NotesAdmin)
