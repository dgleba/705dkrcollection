import random
import string

from django.contrib.auth.models import User
from django.contrib.auth.models import AbstractUser
from django.contrib.auth.models import AbstractBaseUser
from django.contrib.auth.models import Group
from django.contrib.contenttypes.models import ContentType

from menuapp import models as menuapp_models
from blogapp import models as blogapp_models
from hedgedoc import models as hedgedoc_models


def random_string(length=10):
    # Create a random string of length length
    letters = string.ascii_lowercase
    return "".join(random.choice(letters) for i in range(length))


def create_User(**kwargs):
    defaults = {
        "username": "%s_username" % random_string(5),
        "email": "%s_username@tempurl.com" % random_string(5),
    }
    defaults.update(**kwargs)
    return User.objects.create(**defaults)


def create_AbstractUser(**kwargs):
    defaults = {
        "username": "%s_username" % random_string(5),
        "email": "%s_username@tempurl.com" % random_string(5),
    }
    defaults.update(**kwargs)
    return AbstractUser.objects.create(**defaults)


def create_AbstractBaseUser(**kwargs):
    defaults = {
        "username": "%s_username" % random_string(5),
        "email": "%s_username@tempurl.com" % random_string(5),
    }
    defaults.update(**kwargs)
    return AbstractBaseUser.objects.create(**defaults)


def create_Group(**kwargs):
    defaults = {
        "name": "%s_group" % random_string(5),
    }
    defaults.update(**kwargs)
    return Group.objects.create(**defaults)


def create_ContentType(**kwargs):
    defaults = {
    }
    defaults.update(**kwargs)
    return ContentType.objects.create(**defaults)


def create_menuapp_Menu0(**kwargs):
    defaults = {}
    defaults["mapplication"] = ""
    defaults["mstatus"] = ""
    defaults["mdescription"] = ""
    defaults["mcomment"] = ""
    defaults["msort"] = ""
    defaults["mlink"] = ""
    defaults.update(**kwargs)
    return menuapp_models.Menu0.objects.create(**defaults)
def create_blogapp_Post(**kwargs):
    defaults = {}
    defaults["body"] = ""
    defaults["title"] = ""
    defaults.update(**kwargs)
    return blogapp_models.Post.objects.create(**defaults)
def create_hedgedoc_Notes(**kwargs):
    defaults = {}
    defaults["shortid"] = ""
    defaults["title"] = ""
    defaults["permission"] = ""
    defaults["content"] = ""
    defaults["id"] = ""
    defaults["alias"] = ""
    defaults["viewcount"] = ""
    defaults["authorship"] = ""
    defaults.update(**kwargs)
    return hedgedoc_models.Notes.objects.create(**defaults)
