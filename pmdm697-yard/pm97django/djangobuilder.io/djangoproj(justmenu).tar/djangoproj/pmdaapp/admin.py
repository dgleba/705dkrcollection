from django.contrib import admin
from django import forms

from . import models


class MenumodelAdminForm(forms.ModelForm):

    class Meta:
        model = models.Menumodel
        fields = "__all__"


class MenumodelAdmin(admin.ModelAdmin):
    form = MenumodelAdminForm
    list_display = [
        "mcomment",
        "mstatus",
        "updated_at",
        "mapplication",
        "mlink",
        "mdescription",
        "created_at",
        "msort",
    ]
    readonly_fields = [
        "mcomment",
        "mstatus",
        "updated_at",
        "mapplication",
        "mlink",
        "mdescription",
        "created_at",
        "msort",
    ]


admin.site.register(models.Menumodel, MenumodelAdmin)
