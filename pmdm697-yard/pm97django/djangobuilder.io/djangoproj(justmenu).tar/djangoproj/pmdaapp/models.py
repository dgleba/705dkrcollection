from django.db import models
from django.urls import reverse


class Menumodel(models.Model):

    # Fields
    mcomment = models.CharField(max_length=230)
    mstatus = models.IntegerField()
    updated_at = models.DateTimeField(auto_now=True, editable=False)
    mapplication = models.CharField(max_length=350)
    mlink = models.URLField()
    mdescription = models.CharField(max_length=930)
    created_at = models.DateTimeField(auto_now_add=True, editable=False)
    msort = models.IntegerField()

    class Meta:
        pass

    def __str__(self):
        return str(self.pk)

    def get_absolute_url(self):
        return reverse("pmdaapp_Menumodel_detail", args=(self.pk,))

    def get_update_url(self):
        return reverse("pmdaapp_Menumodel_update", args=(self.pk,))

