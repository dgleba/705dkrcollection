from django import forms
from . import models


class MenumodelForm(forms.ModelForm):
    class Meta:
        model = models.Menumodel
        fields = [
            "mcomment",
            "mstatus",
            "mapplication",
            "mlink",
            "mdescription",
            "msort",
        ]
