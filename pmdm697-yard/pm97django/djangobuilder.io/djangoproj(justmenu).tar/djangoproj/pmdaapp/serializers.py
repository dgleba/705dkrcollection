from rest_framework import serializers

from . import models


class MenumodelSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Menumodel
        fields = [
            "mcomment",
            "mstatus",
            "updated_at",
            "mapplication",
            "mlink",
            "mdescription",
            "created_at",
            "msort",
        ]
