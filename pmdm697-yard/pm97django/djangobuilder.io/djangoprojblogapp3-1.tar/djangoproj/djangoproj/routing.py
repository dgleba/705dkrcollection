from django.conf.urls import url

from channels.routing import ChannelNameRouter, ProtocolTypeRouter, URLRouter
from channels.auth import AuthMiddlewareStack

from djangoproj.consumers import djangoproj_WebSocketConsumer

# Consumer Imports
from blogapp3.consumers import blogapp3Consumer


application = ProtocolTypeRouter({

    # WebSocket handler
    "websocket": AuthMiddlewareStack(
        URLRouter([
            url(r"^ws/$", djangoproj_WebSocketConsumer.as_asgi()),
        ])
    ),
    "channel": ChannelNameRouter({
        "blogapp3": blogapp3Consumer,
    })
})
