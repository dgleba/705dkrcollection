from django.contrib import admin
from django import forms

from . import models


class NotesAdminForm(forms.ModelForm):

    class Meta:
        model = models.Notes
        fields = "__all__"


class NotesAdmin(admin.ModelAdmin):
    form = NotesAdminForm
    list_display = [
        "title",
        "alias",
        "authorship",
        "id",
        "content",
        "viewcount",
        "shortid",
        "permission",
    ]
    readonly_fields = [
        "title",
        "alias",
        "authorship",
        "id",
        "content",
        "viewcount",
        "shortid",
        "permission",
    ]


admin.site.register(models.Notes, NotesAdmin)
