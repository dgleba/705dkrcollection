from rest_framework import serializers

from . import models


class NotesSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.Notes
        fields = [
            "title",
            "alias",
            "authorship",
            "id",
            "content",
            "viewcount",
            "shortid",
            "permission",
        ]
