from django.db import models
from django.urls import reverse


class Notes(models.Model):

    # Fields
    title = models.TextField()
    alias = models.CharField()
    authorship = models.TextField()
    id = models.CharField()
    content = models.TextField()
    viewcount = models.IntegerField()
    shortid = models.CharField()
    permission = models.CharField()

    class Meta:
        pass

    def __str__(self):
        return str(self.pk)

    def get_absolute_url(self):
        return reverse("hedgedoc_Notes_detail", args=(self.pk,))

    def get_update_url(self):
        return reverse("hedgedoc_Notes_update", args=(self.pk,))

