import random
import string

from django.contrib.auth.models import User
from django.contrib.auth.models import AbstractUser
from django.contrib.auth.models import AbstractBaseUser
from django.contrib.auth.models import Group
from django.contrib.contenttypes.models import ContentType
from datetime import datetime

from hedgedoc import models as hedgedoc_models
from blogapp import models as blogapp_models
from pmdaapp import models as pmdaapp_models


def random_string(length=10):
    # Create a random string of length length
    letters = string.ascii_lowercase
    return "".join(random.choice(letters) for i in range(length))


def create_User(**kwargs):
    defaults = {
        "username": "%s_username" % random_string(5),
        "email": "%s_username@tempurl.com" % random_string(5),
    }
    defaults.update(**kwargs)
    return User.objects.create(**defaults)


def create_AbstractUser(**kwargs):
    defaults = {
        "username": "%s_username" % random_string(5),
        "email": "%s_username@tempurl.com" % random_string(5),
    }
    defaults.update(**kwargs)
    return AbstractUser.objects.create(**defaults)


def create_AbstractBaseUser(**kwargs):
    defaults = {
        "username": "%s_username" % random_string(5),
        "email": "%s_username@tempurl.com" % random_string(5),
    }
    defaults.update(**kwargs)
    return AbstractBaseUser.objects.create(**defaults)


def create_Group(**kwargs):
    defaults = {
        "name": "%s_group" % random_string(5),
    }
    defaults.update(**kwargs)
    return Group.objects.create(**defaults)


def create_ContentType(**kwargs):
    defaults = {
    }
    defaults.update(**kwargs)
    return ContentType.objects.create(**defaults)


def create_hedgedoc_Notes(**kwargs):
    defaults = {}
    defaults["title"] = ""
    defaults["alias"] = ""
    defaults["authorship"] = ""
    defaults["id"] = ""
    defaults["content"] = ""
    defaults["viewcount"] = ""
    defaults["shortid"] = ""
    defaults["permission"] = ""
    defaults.update(**kwargs)
    return hedgedoc_models.Notes.objects.create(**defaults)
def create_blogapp_Post(**kwargs):
    defaults = {}
    defaults["title"] = ""
    defaults["body"] = ""
    defaults.update(**kwargs)
    return blogapp_models.Post.objects.create(**defaults)
def create_pmdaapp_menu(**kwargs):
    defaults = {}
    defaults["mcomment"] = ""
    defaults["mlink"] = ""
    defaults["mstatus"] = ""
    defaults["created_at"] = datetime.now()
    defaults["mapplication"] = ""
    defaults["mdescription"] = ""
    defaults["updated_at"] = datetime.now()
    defaults["msort"] = ""
    defaults.update(**kwargs)
    return pmdaapp_models.menu.objects.create(**defaults)
