from rest_framework import serializers

from . import models


class menuSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.menu
        fields = [
            "mcomment",
            "mlink",
            "mstatus",
            "created_at",
            "mapplication",
            "mdescription",
            "updated_at",
            "msort",
        ]
