from rest_framework import viewsets, permissions

from . import serializers
from . import models


class menuViewSet(viewsets.ModelViewSet):
    """ViewSet for the menu class"""

    queryset = models.menu.objects.all()
    serializer_class = serializers.menuSerializer
    permission_classes = [permissions.IsAuthenticated]
