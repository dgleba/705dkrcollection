from django.urls import path, include
from rest_framework import routers

from . import api
from . import views


router = routers.DefaultRouter()
router.register("menu", api.menuViewSet)

urlpatterns = (
    path("api/v1/", include(router.urls)),
    path("pmdaapp/menu/", views.menuListView.as_view(), name="pmdaapp_menu_list"),
    path("pmdaapp/menu/create/", views.menuCreateView.as_view(), name="pmdaapp_menu_create"),
    path("pmdaapp/menu/detail/<int:pk>/", views.menuDetailView.as_view(), name="pmdaapp_menu_detail"),
    path("pmdaapp/menu/update/<int:pk>/", views.menuUpdateView.as_view(), name="pmdaapp_menu_update"),
    path("pmdaapp/menu/delete/<int:pk>/", views.menuDeleteView.as_view(), name="pmdaapp_menu_delete"),

)
