from django.contrib import admin
from django import forms

from . import models


class menuAdminForm(forms.ModelForm):

    class Meta:
        model = models.menu
        fields = "__all__"


class menuAdmin(admin.ModelAdmin):
    form = menuAdminForm
    list_display = [
        "mcomment",
        "mlink",
        "mstatus",
        "created_at",
        "mapplication",
        "mdescription",
        "updated_at",
        "msort",
    ]
    readonly_fields = [
        "mcomment",
        "mlink",
        "mstatus",
        "created_at",
        "mapplication",
        "mdescription",
        "updated_at",
        "msort",
    ]


admin.site.register(models.menu, menuAdmin)
