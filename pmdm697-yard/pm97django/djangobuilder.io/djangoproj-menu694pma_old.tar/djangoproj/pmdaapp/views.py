from django.views import generic
from django.urls import reverse_lazy
from . import models
from . import forms


class menuListView(generic.ListView):
    model = models.menu
    form_class = forms.menuForm


class menuCreateView(generic.CreateView):
    model = models.menu
    form_class = forms.menuForm


class menuDetailView(generic.DetailView):
    model = models.menu
    form_class = forms.menuForm


class menuUpdateView(generic.UpdateView):
    model = models.menu
    form_class = forms.menuForm
    pk_url_kwarg = "pk"


class menuDeleteView(generic.DeleteView):
    model = models.menu
    success_url = reverse_lazy("pmdaapp_menu_list")
