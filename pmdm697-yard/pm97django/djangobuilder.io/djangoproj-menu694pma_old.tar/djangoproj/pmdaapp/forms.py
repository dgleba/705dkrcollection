from django import forms
from . import models


class menuForm(forms.ModelForm):
    class Meta:
        model = models.menu
        fields = [
            "mcomment",
            "mlink",
            "mstatus",
            "created_at",
            "mapplication",
            "mdescription",
            "updated_at",
            "msort",
        ]
