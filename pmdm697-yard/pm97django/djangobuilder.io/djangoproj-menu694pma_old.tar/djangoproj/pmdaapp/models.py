from django.db import models
from django.urls import reverse


class menu(models.Model):

    # Fields
    mcomment = models.CharField()
    mlink = models.URLField()
    mstatus = models.IntegerField()
    created_at = models.DateTimeField()
    mapplication = models.CharField()
    mdescription = models.CharField()
    updated_at = models.DateTimeField()
    msort = models.IntegerField()

    class Meta:
        pass

    def __str__(self):
        return str(self.pk)

    def get_absolute_url(self):
        return reverse("pmdaapp_menu_detail", args=(self.pk,))

    def get_update_url(self):
        return reverse("pmdaapp_menu_update", args=(self.pk,))

