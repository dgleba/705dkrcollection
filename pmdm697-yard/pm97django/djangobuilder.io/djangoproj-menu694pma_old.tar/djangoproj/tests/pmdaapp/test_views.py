import pytest
import test_helpers

from django.urls import reverse


pytestmark = [pytest.mark.django_db]


def tests_menu_list_view(client):
    instance1 = test_helpers.create_pmdaapp_menu()
    instance2 = test_helpers.create_pmdaapp_menu()
    url = reverse("pmdaapp_menu_list")
    response = client.get(url)
    assert response.status_code == 200
    assert str(instance1) in response.content.decode("utf-8")
    assert str(instance2) in response.content.decode("utf-8")


def tests_menu_create_view(client):
    url = reverse("pmdaapp_menu_create")
    data = {
        "mcomment": "text",
        "mlink": http://127.0.0.1,
        "mstatus": 1,
        "created_at": datetime.now(),
        "mapplication": "text",
        "mdescription": "text",
        "updated_at": datetime.now(),
        "msort": 1,
    }
    response = client.post(url, data)
    assert response.status_code == 302


def tests_menu_detail_view(client):
    instance = test_helpers.create_pmdaapp_menu()
    url = reverse("pmdaapp_menu_detail", args=[instance.pk, ])
    response = client.get(url)
    assert response.status_code == 200
    assert str(instance) in response.content.decode("utf-8")


def tests_menu_update_view(client):
    instance = test_helpers.create_pmdaapp_menu()
    url = reverse("pmdaapp_menu_update", args=[instance.pk, ])
    data = {
        "mcomment": "text",
        "mlink": http://127.0.0.1,
        "mstatus": 1,
        "created_at": datetime.now(),
        "mapplication": "text",
        "mdescription": "text",
        "updated_at": datetime.now(),
        "msort": 1,
    }
    response = client.post(url, data)
    assert response.status_code == 302
