from django.contrib import admin
from django import forms

from . import models


class NotesAdminForm(forms.ModelForm):

    class Meta:
        model = models.Notes
        fields = "__all__"


class NotesAdmin(admin.ModelAdmin):
    form = NotesAdminForm
    list_display = [
        "alias",
        "title",
        "content",
        "id",
        "permission",
        "authorship",
        "viewcount",
        "shortid",
    ]
    readonly_fields = [
        "alias",
        "title",
        "content",
        "id",
        "permission",
        "authorship",
        "viewcount",
        "shortid",
    ]


admin.site.register(models.Notes, NotesAdmin)
