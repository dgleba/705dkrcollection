from rest_framework import serializers

from . import models


class Menu0Serializer(serializers.ModelSerializer):

    class Meta:
        model = models.Menu0
        fields = [
            "updated_at",
            "created_at",
            "msort",
            "mstatus",
            "mlink",
            "mcomment",
            "mdescription",
            "mapplication",
        ]
